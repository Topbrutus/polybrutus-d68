# Polybrutus D67 — prior same-author mathematical publications

These are earlier same-author works, **not independent external peer review**.

[1] St-Pierre, Gabriel (2026). *Polybrutus 66D: Exact 71-Point Euclidean Metric and Sixtyfold Ideal Graph Mode*. Zenodo DOI [10.5281/zenodo.24432778](https://doi.org/10.5281/zenodo.24432778). Direct immutable scientific parent. Frozen [Git source D66 v0.1.0](https://github.com/Topbrutus/polybrutus-d66/tree/v0.1.0), peeled scientific commit 7e66bbf611a4092b3c1fa02031fbcf6bd5f0afd2.

[2] St-Pierre, Gabriel (2026). *Polybrutus 7D: An Exact Twelve-Point Orthogonal Completion, the 12-35-37 Identity, and an Oscillator Model*. Zenodo DOI [10.5281/zenodo.24407952](https://doi.org/10.5281/zenodo.24407952). Historical reference, not immediate parent.

[3] St-Pierre, Gabriel (2026). Complete original Polybrutus D66 frozen scientific source v0.1.0, https://github.com/Topbrutus/polybrutus-d66/tree/v0.1.0, original entire ZIP SHA256 \`f974a9b5952e8a5ccdec795431508612f4c17acae5af52e42eb784bb3f4d874c\`, archived untouched within D67.

Official Zenodo: exactly nine current \`sixty-seven\` / \`sixty-onefold\` keywords, structured \`isDerivedFrom\` direct D66 DOI, two separate bibliographic entries D66 and D7.
