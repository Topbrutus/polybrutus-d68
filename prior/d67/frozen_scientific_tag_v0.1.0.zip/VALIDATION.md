# Polybrutus D67 — proof-first validation and controlled publication

1. Direct scientific parent D66 frozen v0.1.0 peeled Git commit 7e66bbf611a4092b3c1fa02031fbcf6bd5f0afd2, DOI 10.5281/zenodo.24432778, entire original source ZIP SHA256 f974a9b5952e8a5ccdec795431508612f4c17acae5af52e42eb784bb3f4d874c, certificate SHA256 227834b7a7c230823edbea4d7b4b0fb721890a065fea14a9aea01dfb89655c55. Both exact programs validate original ZIP SHA/CRC, original certificate bytes and inherited labels.
2. Exhaust all 72 norm-one points and 2556 labelled exact squared distances; 2485 unchanged old D66 pairs and 71 new squared distances 2R²; Euclidean Gram and centered Gram PSD rank 67.
3. Two independent implementations (SymPy exact Gram vs fractions.Fraction separate pair rules), four adversarial negative controls, exact deterministic certificate. Chosen dimensionless ideal graph eigenvalue 36 mult 61 and 71/2 mult 4.
4. Scientific GitHub initial main CI must pass, then freeze source tag v0.1.0 and require tag CI green; after public Zenodo DOI document on main and require third green CI.
5. Public Zenodo originals: full frozen Git scientific source ZIP, two-page mathematical PDF and exact deterministic certificate JSON; all 3 filenames, sizes and MD5 from public API match SHA256-verified originals. Nine current D67 sixty-seven/sixty-onefold keywords, structured isDerivedFrom direct D66 DOI, separate D66/D7 textual bibliography.
6. Preserve entire historic original source ZIP nesting unchanged, disclose D47/D46 historical parent text SHA mistake, never claim physical spacetime, measured hertz or new universal theorem.

    python -m pip install sympy==1.14.0
    python src/verify_d67.py
    python tests/independent_d67.py
    python src/check_zenodo_metadata.py
