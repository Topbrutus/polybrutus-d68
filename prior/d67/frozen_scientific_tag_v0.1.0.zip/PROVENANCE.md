# Polybrutus D67 — immutable full source lineage and AI disclosure

**Human scientific author:** Gabriel St-Pierre, independent researcher. OpenAI ChatGPT (Astra) materially assisted independent rational verification programs, mathematical writing and controlled publication; AI is not the scientific author.

**Sole direct scientific parent:** Topbrutus/polybrutus-d66@v0.1.0, true peeled SHA \`7e66bbf611a4092b3c1fa02031fbcf6bd5f0afd2\`, DOI 10.5281/zenodo.24432778. Entire original scientific Git source ZIP \`prior/d66/frozen_scientific_tag_v0.1.0.zip\`: **4499678 bytes, 32 entries, ZIP CRC PASS**, SHA256 \`f974a9b5952e8a5ccdec795431508612f4c17acae5af52e42eb784bb3f4d874c\`. All original ancestor full source ZIP archives remain nested byte-identically. Original certificate \`prior/d66/results/certificate_d66.json\`: **187956 bytes**, SHA256 \`227834b7a7c230823edbea4d7b4b0fb721890a065fea14a9aea01dfb89655c55\`, copied unchanged. Both D67 programs authenticate ZIP SHA/CRC, original certificate bytes and every one of **2485** old labelled squared-distance values.

**Historical discrepancy disclosed since D48:** original D47 certificate contains an incorrect textual D46 grandparent Git commit. All original source archives remain unchanged; the direct D66 tag is independently authenticated. Any CRLF/LF text normalization is permitted for comparison of ZIP contents to Git blobs only, never a rewrite of the original ZIP.

Zenodo requires structured \`isDerivedFrom\` direct D66 DOI 10.5281/zenodo.24432778 and separate D66/D7 references 10.5281/zenodo.24407952.
**Limits:** This establishes one synthetic exact Euclidean labelled metric and a separately stipulated dimensionless ideal weighted graph, not observed physical spacetime dimensions, measured hertz, newly discovered particles, a universal mathematical theorem or independent human peer review.
