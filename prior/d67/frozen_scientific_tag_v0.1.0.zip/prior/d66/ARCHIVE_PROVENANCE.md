# Polybrutus D66 — complete original frozen scientific source

- Direct parent original tag: https://github.com/Topbrutus/polybrutus-d66/tree/v0.1.0, peeled commit \`7e66bbf611a4092b3c1fa02031fbcf6bd5f0afd2\`.
- Zenodo DOI 10.5281/zenodo.24432778.
- Full original source \`frozen_scientific_tag_v0.1.0.zip\`: **4499678 bytes**, **32 entries**, ZIP CRC PASS, SHA256 \`f974a9b5952e8a5ccdec795431508612f4c17acae5af52e42eb784bb3f4d874c\`.
- Exact original \`results/certificate_d66.json\`: **187956 bytes**, SHA256 \`227834b7a7c230823edbea4d7b4b0fb721890a065fea14a9aea01dfb89655c55\`.
- All ancestor original complete source ZIPs remain embedded without modification, including original historical D47/D46 textual SHA inconsistency disclosed since D48.
