# Polybrutus 67D — Exact 72-point Euclidean metric and sixty-onefold ideal graph mode

**Human scientific author:** Gabriel St-Pierre, independent researcher.
**Material AI assistance:** OpenAI ChatGPT (Astra) materially assisted independent exact rational programs, verification, scientific manuscript, metadata and controlled publication. AI is not the scientific author.

## Exact reproducible mathematical results

- **72** unit-norm points, **2556 / 2556** labelled exact rational squared-distance pairs.
- **2485 / 2485** labelled predecessor D66 distances conserved; **71** added squared distances each **2R²**.
- PSD rational Euclidean Gram and PSD centered Gram of exact **affine rank 67**, minimal Euclidean dimension for this synthetic metric, with 68 coordinate storage.
- Full normalized histogram \`k=4d²/R²\`, R=1: 4:6, 7:2, 8:2525, 9:3, 10:10, 12:6, 13:2, 16:2. Exact sum R=1: **20495/4**.
- Separately freely stipulated dimensionless ideal equal-scalar-mass weighted complete graph \`w_ij=1/d_ij²\`: eigenvalue **36 multiplicity 61**, and **71/2 multiplicity 4**. Not observed hertz.
- Two independent exact rational implementations and four primary adversarial negative controls, authentication of full original D66 source tag archive and original certificate by SHA256/CRC.

Reproduce using Python 3.12, sympy==1.14.0:

    python -m pip install sympy==1.14.0
    python src/verify_d67.py
    python tests/independent_d67.py
    python src/check_zenodo_metadata.py

Both verifiers reproduce the identical deterministic certificate \`results/certificate_d67.json\`. GitHub Actions executes both exact verifiers, deterministic certificate check and current bibliography metadata QA.

## Only original frozen scientific parent

[Polybrutus D66 v0.1.0](https://github.com/Topbrutus/polybrutus-d66/tree/v0.1.0), true peeled commit \`7e66bbf611a4092b3c1fa02031fbcf6bd5f0afd2\`, DOI [10.5281/zenodo.24432778](https://doi.org/10.5281/zenodo.24432778). Its **entire original full scientific Git tag ZIP**, including all older original source ZIP archives nested unchanged, is embedded byte-identically at \`prior/d66/frozen_scientific_tag_v0.1.0.zip\` SHA256 \`f974a9b5952e8a5ccdec795431508612f4c17acae5af52e42eb784bb3f4d874c\`; original D66 certificate remains byte-identical SHA256 \`227834b7a7c230823edbea4d7b4b0fb721890a065fea14a9aea01dfb89655c55\`.

Official Zenodo metadata must include nine D67-specific keywords (\`sixty-seven\`, \`sixty-onefold\`), structured \`isDerivedFrom\` direct D66 DOI 10.5281/zenodo.24432778 and **separate** bibliographic references to D66 and historic D7 DOI 10.5281/zenodo.24407952.

[Specification](SPECIFICATION_D67.md) | [constructive proof](PREUVE_D67.md) | [provenance](PROVENANCE.md) | [references](REFERENCES.md) | [two-page PDF](publication/POLYBRUTUS_67D_NOTE.pdf).

**Scope:** This establishes one synthetic exact Euclidean labelled metric and a separately stipulated dimensionless ideal weighted graph, not observed physical spacetime dimensions, measured hertz, newly discovered particles, a universal mathematical theorem or independent human peer review. **Software MIT, manuscript CC BY 4.0.**
