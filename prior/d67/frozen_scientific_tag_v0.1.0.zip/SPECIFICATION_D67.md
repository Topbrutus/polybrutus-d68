# Polybrutus D67 — exact 72-point labelled Euclidean squared-distance metric

**Exclusive direct parent scientific source:** Topbrutus/polybrutus-d66@v0.1.0, actual peeled scientific Git commit \`7e66bbf611a4092b3c1fa02031fbcf6bd5f0afd2\`, DOI 10.5281/zenodo.24432778, original full source ZIP SHA256 \`f974a9b5952e8a5ccdec795431508612f4c17acae5af52e42eb784bb3f4d874c\`, original D66 certificate SHA256 \`227834b7a7c230823edbea4d7b4b0fb721890a065fea14a9aea01dfb89655c55\`.

## Conservative perpendicular norm-one extension

Embed all 71 predecessor norm-one vectors p_i as q_i=(p_i,0). Append one perpendicular unit vector q_72. Every one of C(71,2)=2485 old labelled squared distances remains unchanged; all 71 new squared distances equal 2R². Total C(72,2)=2556 labelled unordered pairs.

Construct a rational Gram G as orthogonal sum of seven original canonical norm-one points (Gram rank 3), a separate centered five-point regular unit simplex (rank 4) with mutual inner products -1/4, and **60** independent mutually orthogonal norm-one axes (rank 60). Hence G=XXᵀ is PSD, unit diagonal, exact rank **3+4+60=67**. Set D_ii=0 and D_ij=2-2G_ij. With H=I-11ᵀ/72, B=-(HDH)/2=HGH is PSD of rank **67**. An inherited canonical antipodal point pair implies the origin lies in the affine hull. Minimum affine Euclidean dimension of this particular metric is therefore 67 (68 coordinate storage).

At R=1, \`k=4d²/R²\` exact histogram: 4:6, 7:2, 8:2525, 9:3, 10:10, 12:6, 13:2, 16:2; total 2556. Exact sum of squared pair distances R=1: **20495/4**.

## Independently stipulated ideal weighted graph

Freely choose scalar unit masses, weighted complete edges w_ij=1/d_ij². New point connects to all 71 old points with weight 1/2. The chosen ideal Laplacian is L67=[[L66+I71/2,-1_71/2],[-1_71ᵀ/2,71/2]]. Its characteristic recurrence is chi72(z)=z(z-36)chi71(z-1/2)/(z-1/2).
Using the inherited seven-point factor f6(z)=chiP7(z)/z:
chi72(z)=z(z-36)^61(z-71/2)^4*f6(z-65/2).
Exact rational nullities yield Laplacian eigenvalue **36 multiplicity 61**, and **71/2 multiplicity 4**. These values are dimensionless model eigenmodes, not physical frequencies.

**Bibliography:** immediate D66 DOI 10.5281/zenodo.24432778; historical D7 DOI 10.5281/zenodo.24407952.
