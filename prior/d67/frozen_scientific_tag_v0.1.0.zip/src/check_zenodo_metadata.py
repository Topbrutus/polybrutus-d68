#!/usr/bin/env python3
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
c=json.loads((R/'results/certificate_d67.json').read_text('utf8'))
m=json.loads((R/'publication/zenodo_metadata_blueprint.json').read_text('utf8'))
assert c['status']=='PASS' and c['dimension']==m['scientific_dimension']==67
assert c['vertices']==m['norm_one_vertices']==72
assert c['pairs']==m['exact_labelled_squared_pairs']==2556
assert c['affine_rank']==c['centered_gram_rank']==67
assert c['eigenvalue_36_multiplicity']==m['model_eigenvalue_36_multiplicity']==61
assert c['eigenvalue_71_over_2_multiplicity']==m['model_eigenvalue_71_over_2_multiplicity']==4
assert c['parent_tag_commit']=='7e66bbf611a4092b3c1fa02031fbcf6bd5f0afd2'
assert c['parent_doi']==m['scientific_parent_doi']=='10.5281/zenodo.24432778'
assert m['related_identifiers']==[{'identifier':'10.5281/zenodo.24432778','relation':'isDerivedFrom','resource_type':'publication-preprint','scheme':'doi'}]
assert len(m['keywords'])==9
assert 'affine Euclidean dimension sixty-seven' in m['keywords']
assert 'sixty-onefold ideal eigenvalue' in m['keywords']
assert len(m['references'])==2
assert '10.5281/zenodo.24432778' in m['references'][0]
assert '10.5281/zenodo.24407952' in m['references'][1]
assert not set(m['keywords']).intersection({'affine Euclidean dimension sixty-six','sixtyfold ideal eigenvalue','affine Euclidean dimension sixty-eight','sixty-twofold ideal eigenvalue'})
note=(R/'publication/POLYBRUTUS_67D_NOTE.md').read_text('utf8')
assert all(x in note for x in ('## References','10.5281/zenodo.24432778','10.5281/zenodo.24407952'))
print('D67_CURRENT_9_KEYWORDS_STRUCTURED_DIRECT_D66_PARENT_AND_SEPARATE_D66_D7_REFERENCES_PASS')
